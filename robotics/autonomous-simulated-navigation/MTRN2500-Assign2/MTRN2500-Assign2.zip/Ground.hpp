
#ifndef MTRN3500_GROUND_H
#define MTRN3500_GROUND_H

class Ground {
  
public:

  static void draw();
  
};

#endif // for MTRN3500_GROUND_H
